-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2023 at 07:12 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grainsmart`
--

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

CREATE TABLE `complaint` (
  `comp_id` int(10) NOT NULL,
  `c_id` int(10) NOT NULL,
  `decscription` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`comp_id`, `c_id`, `decscription`) VALUES
(1, 1, 'complaint'),
(2, 1, ''),
(3, 1, ''),
(4, 1, ''),
(5, 1, 'grains is very best'),
(6, 1, 'grains are not dry\r\n'),
(7, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `c_id` int(10) NOT NULL,
  `c_username` varchar(20) NOT NULL,
  `c_password` varchar(18) NOT NULL,
  `c_Name` varchar(20) NOT NULL,
  `c_email` varchar(45) NOT NULL,
  `c_MobileNo` varchar(10) NOT NULL,
  `c_Address` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`c_id`, `c_username`, `c_password`, `c_Name`, `c_email`, `c_MobileNo`, `c_Address`) VALUES
(1, 'customer1', 'Shubh@4011', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', '9309193517', 'Pachora'),
(3, 'customer2', 'Shubh@4011', 'Vishwajit', 'vishwajitspatil1929@gmail.com', '9309193517', 'Pachora'),
(4, 'Vishwa', 'Shubh@4011', 'vishwajit', 'abc@123gmail.com', '8806447671', 'pune'),
(5, 'farmer2', 'Vishwa@1929', 'gaurav patil', 'gaurav1111@gmail.com', '9309193517', 'jalgoan'),
(6, 'customer3', 'Shubh@4011', 'gaurav', 'gaurav1111@gmail.com', '8806447671', 'jalgoan');

-- --------------------------------------------------------

--
-- Table structure for table `farmer`
--

CREATE TABLE `farmer` (
  `f_id` int(10) NOT NULL,
  `f_username` varchar(20) NOT NULL,
  `f_password` varchar(20) NOT NULL,
  `f_Name` varchar(20) NOT NULL,
  `f_email` varchar(45) NOT NULL,
  `f_MobileNo` int(10) NOT NULL,
  `f_Address` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `farmer`
--

INSERT INTO `farmer` (`f_id`, `f_username`, `f_password`, `f_Name`, `f_email`, `f_MobileNo`, `f_Address`) VALUES
(1, 'farmer1', 'Shubh@4011', 'farmer', 'abc@gmail.com', 2147483647, 'pune'),
(2, 'farmer3', 'Shubh@4011', 'raj', 'raj@123gmail.com', 2147483647, 'pune'),
(3, 'farmer5', 'Shubh@4011', 'aftaph', 'aftaph12@gmail.com', 2147483647, 'solapur');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `feed_id` int(10) NOT NULL,
  `c_id` int(10) NOT NULL,
  `decscription` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feed_id`, `c_id`, `decscription`) VALUES
(1, 0, ''),
(2, 0, ''),
(3, 0, ''),
(4, 0, ''),
(5, 0, ''),
(6, 0, ''),
(7, 0, ''),
(8, 0, ''),
(9, 1, ''),
(10, 1, ''),
(11, 1, ''),
(12, 1, 'jjjjjjjjjj'),
(13, 1, 'jjjjjjjjjj'),
(14, 1, ''),
(15, 1, ''),
(16, 1, ''),
(17, 1, ''),
(18, 1, ''),
(19, 1, ''),
(20, 1, 'feedback'),
(21, 1, ''),
(22, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `grains`
--

CREATE TABLE `grains` (
  `grains_id` int(10) NOT NULL,
  `grains_name` varchar(20) NOT NULL,
  `grains_variety` varchar(30) NOT NULL,
  `grains_price` float NOT NULL,
  `grains_stock` int(10) NOT NULL,
  `f_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `grains`
--

INSERT INTO `grains` (`grains_id`, `grains_name`, `grains_variety`, `grains_price`, `grains_stock`, `f_id`) VALUES
(1, 'Rice', 'Bhasmati', 90, 1528, 1),
(3, 'Jowar', 'hybrid', 50, 400, 1),
(4, 'Wheat', 'hybrid', 30, 880, 1),
(5, 'Bajra', 'Gaint Bajra', 40, 500, 1),
(6, 'Corn', 'Dent Corn', 40, 560, 1),
(7, 'Bajra', 'hybrid', 50, 400, 3);

-- --------------------------------------------------------

--
-- Table structure for table `order1`
--

CREATE TABLE `order1` (
  `order_id` int(10) NOT NULL,
  `c_id` int(10) NOT NULL,
  `f_d` int(10) NOT NULL,
  `g_id` int(10) NOT NULL,
  `order_quantity` int(10) NOT NULL,
  `total_bill` float NOT NULL,
  `delivery_add` varchar(45) NOT NULL,
  `order_date` date NOT NULL,
  `grains_name` varchar(20) NOT NULL,
  `grains_variety` varchar(20) NOT NULL,
  `grains_price` float NOT NULL,
  `f_Name` varchar(20) NOT NULL,
  `f_email` varchar(45) NOT NULL,
  `f_MobileNo` int(10) NOT NULL,
  `f_Address` varchar(45) NOT NULL,
  `c_Name` varchar(20) NOT NULL,
  `c_email` varchar(45) NOT NULL,
  `c_MobileNo` int(10) NOT NULL,
  `c_Address` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order1`
--

INSERT INTO `order1` (`order_id`, `c_id`, `f_d`, `g_id`, `order_quantity`, `total_bill`, `delivery_add`, `order_date`, `grains_name`, `grains_variety`, `grains_price`, `f_Name`, `f_email`, `f_MobileNo`, `f_Address`, `c_Name`, `c_email`, `c_MobileNo`, `c_Address`) VALUES
(1, 1, 1, 1, 20, 1800, 'pune', '2023-06-25', 'Rice', 'Bhasmati', 90, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', 2147483647, 'Pachora'),
(2, 1, 1, 1, 20, 1800, 'pune', '2023-06-25', 'Rice', 'Bhasmati', 90, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', 2147483647, 'Pachora'),
(3, 1, 1, 1, 102, 9180, 'pune', '2023-06-25', 'Rice', 'Bhasmati', 90, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', 2147483647, 'Pachora'),
(4, 1, 1, 1, 102, 9180, 'pune', '2023-06-25', 'Rice', 'Bhasmati', 90, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', 2147483647, 'Pachora'),
(5, 1, 1, 1, 50, 4500, 'pune', '2023-07-08', 'Rice', 'Bhasmati', 90, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', 2147483647, 'Pachora'),
(6, 1, 1, 1, 50, 4500, 'pune', '2023-07-08', 'Rice', 'Bhasmati', 90, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', 2147483647, 'Pachora'),
(7, 1, 1, 4, 20, 600, 'pune', '2023-07-09', 'Wheat', 'hybrid', 30, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', 2147483647, 'Pachora'),
(8, 1, 1, 4, 20, 600, 'pune', '2023-07-09', 'Wheat', 'hybrid', 30, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', 2147483647, 'Pachora'),
(9, 6, 1, 3, 100, 5000, 'jalgoan', '2023-07-09', 'Jowar', 'hybrid', 50, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'gaurav', 'gaurav1111@gmail.com', 2147483647, 'jalgoan'),
(10, 6, 1, 3, 100, 5000, 'jalgoan', '2023-07-09', 'Jowar', 'hybrid', 50, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'gaurav', 'gaurav1111@gmail.com', 2147483647, 'jalgoan'),
(11, 1, 1, 6, 40, 1600, 'Pachora', '2023-07-10', 'Corn', 'Dent Corn', 40, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', 2147483647, 'Pachora'),
(12, 1, 1, 6, 40, 1600, 'Pachora', '2023-07-10', 'Corn', 'Dent Corn', 40, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', 2147483647, 'Pachora'),
(13, 1, 1, 4, 100, 3000, 'pune', '2023-07-10', 'Wheat', 'hybrid', 30, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', 2147483647, 'Pachora'),
(14, 1, 1, 4, 100, 3000, 'pune', '2023-07-10', 'Wheat', 'hybrid', 30, 'farmer', 'abc@gmail.com', 2147483647, 'pune', 'Vishwajit Patil', 'vishwajitspatil1929@gmail.com', 2147483647, 'Pachora');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `complaint`
--
ALTER TABLE `complaint`
  ADD PRIMARY KEY (`comp_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `farmer`
--
ALTER TABLE `farmer`
  ADD PRIMARY KEY (`f_id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`feed_id`);

--
-- Indexes for table `grains`
--
ALTER TABLE `grains`
  ADD PRIMARY KEY (`grains_id`);

--
-- Indexes for table `order1`
--
ALTER TABLE `order1`
  ADD PRIMARY KEY (`order_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `complaint`
--
ALTER TABLE `complaint`
  MODIFY `comp_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `c_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `farmer`
--
ALTER TABLE `farmer`
  MODIFY `f_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `feed_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `grains`
--
ALTER TABLE `grains`
  MODIFY `grains_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `order1`
--
ALTER TABLE `order1`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
