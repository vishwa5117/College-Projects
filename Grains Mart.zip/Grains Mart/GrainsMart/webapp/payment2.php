<?php
include("connect.php");
session_start();
date_default_timezone_set("Asia/Kolkata");

$today = date("Y/m/d");
$date = date("d/m/Y");

$g_id = $_POST['g_id'];
$f_id = $_POST['f_id'];
$quantity = $_POST['quantity'];
$add = $_POST['add'];
$bill = $_POST['bill'];
$username = $_SESSION['customer'];

$c_id = "";
$c_username = "";
$c_Name = "";
$c_email = "";
$c_MobileNo = "";
$c_Address = "";

$f_Name = "";
$f_email = "";
$f_MobileNo = "";
$f_Address = "";

$grains_name = "";
$grains_variety = "";
$grains_price = "";
$grains_stock = "";

try {
    

    $stmt = $conn->prepare("SELECT * FROM customer WHERE c_username = ?");
    $stmt->bind_param( $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $c_id = $row["c_id"];
        $c_username = $row["c_username"];
        $c_Name = $row["c_Name"];
        $c_email = $row["c_email"];
        $c_MobileNo = $row["c_MobileNo"];
        $c_Address = $row["c_Address"];
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT * FROM farmer WHERE f_id = ?");
    $stmt->bind_param( $f_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $f_Name = $row["f_Name"];
        $f_email = $row["f_email"];
        $f_MobileNo = $row["f_MobileNo"];
        $f_Address = $row["f_Address"];
    }
    $stmt->close();

    $stmt = $conn->prepare("SELECT * FROM grains WHERE grains_id = ?");
    $stmt->bind_param( $g_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $grains_name = $row["grains_name"];
        $grains_variety = $row["grains_variety"];
        $grains_price = $row["grains_price"];
        $grains_stock = $row["grains_stock"];
    }
    $stmt->close();

    $q2 = intval($grains_stock);
    $q1 = intval($quantity);
    $q2 = $q2 - $q1;
    $stmt = $conn->prepare("UPDATE grains SET grains_stock = ? WHERE grains_id = ?");
    $stmt->bind_param($q2, $g_id);
    $stmt->execute();
    $stmt->close();

$sql = "INSERT INTO order1 (c_id, f_d, g_id, order_quantity, total_bill, delivery_add, order_date, order_week, grains_name, grains_variety, grains_price, f_Name, f_email, f_MobileNo, f_Address, c_Name, c_email, c_MobileNo, c_Address) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";


$stmt = $conn->prepare($sql);
$stmt->bind_param($c_id, $f_id, $g_id, $quantity, $bill, $add, $today, 1, $grains_name, $grains_variety, $grains_price, $f_Name, $f_email, $f_MobileNo, $f_Address, $c_Name, $c_email, $c_MobileNo, $c_Address);

$stmt->execute();

$stmt->close();


    $conn->close();

    echo "<script>alert('Order Confirmed!!');</script>";
} catch (Exception $e) {
    echo $e;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creating PDF from HTML</title>
    <link rel="stylesheet" href="style.css">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link rel="stylesheet" href="css/nav.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.debug.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.4/jspdf.min.js"></script>
</head>
<body>
    <div class="nav">
        <ul>
            <li class="logo">GrainsMart</li>
            <li class="active"><a href="account.php">Account</a></li>
            <li><a href="SellGrain.php">Sell Grains</a></li>
            <li><a href="Grains.php">Order Grains</a></li>
            <li><a href="AboutUs.html">About Us</a></li>
            <li><a href="index.php">Home</a></li>
        </ul>
    </div>
    <div id="whatToPrint" style="width: 1000px;height:2000px">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="invoice-title">
                        <h2>GrainsMart Order Receipt</h2>
                    </div>
                    <hr>
                    <div class="row">
                        <div class="col-xs-6">
                            <address>
                                <strong style="font-size:18px;">Customer Details:</strong><br>
                                <b>Customer Id:</b><?php echo $c_id; ?><br>
                                <b>Username:</b><?php echo $c_username; ?><br>
                                <b>Name:</b><?php echo $c_Name; ?><br>
                                <b>Email:</b><?php echo $c_email; ?><br>
                                <b>Mobile No:</b><?php echo $c_MobileNo; ?><br>
                                <b>Address:</b><?php echo $c_Address; ?><br>
                            </address>
                        </div>
                        <div class="col-xs-2 ">
                            <address>
                                <strong style="font-size:18px;">Farmer Details:</strong><br>
                                <b>Farmer Id:</b><?php echo $f_id; ?><br>
                                <b>Name:</b><?php echo $f_Name; ?><br>
                                <b>Email:</b><?php echo $f_email; ?><br>
                                <b>Mobile No:</b><?php echo $f_MobileNo; ?><br>
                                <b>Address:</b><?php echo $f_Address; ?><br>
                            </address>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-6">
                            <address>
                                <strong>Payment Method:</strong>
                                Online<br>
                                <strong>Payment Status:</strong>
                                Done<br>
                            </address>
                        </div>
                        <div class="col-xs-2 ">
                            <address>
                                <strong>Order Date:</strong><br><?php echo $date; ?>
                                <br><br>
                            </address>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-8">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title"><strong>Order summary</strong></h3>
                        </div>
                        <div class="panel-body">
                            <div class="table-responsive">
                                <div class="row">
                                    <div class="col-xs-6">
                                        <address>
                                            <b>Grain Id:</b><?php echo $g_id; ?><br>
                                            <b>Grain Name:</b><?php echo $grains_name; ?><br>
                                            <b>Grain Variety:</b><?php echo $grains_variety; ?><br>
                                            <b>Delivery Address:</b><?php echo $add; ?><br>
                                        </address>
                                    </div>
                                    <address>
                                        <div class="col-xs-4">
                                            <b>Grain Price:</b><?php echo $grains_price; ?><br>
                                            <b>Order Quantity:</b><?php echo $quantity; ?><br><br>
                                            <strong style="font-size:18px;">Total Bill:</strong><br>
                                            <?php echo $bill; ?><br>
                                        </div>
                                    </address>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button id="cmd">Download PDF</button>
        </div>
    </div>

   <br><br>     <!--<img src="https://th.bing.com/th/id/OIP.wdkLi0wAUuLf5gdNFincPwHaEd?pid=ImgDet&rs=1"/>-->
<div class="btn-group" ">
                <a href="javascript:generatePDF()" id="downloadButton" class="btn btn-lg btn-warning">Click To Download</a>
            </div>
       <!--  <a href="javascript:generatePDF()" id="downloadButton">Click to download</a>-->
    </div>

    <script>
        async function generatePDF() {
            document.getElementById("downloadButton").innerHTML = "Currently downloading, please wait";

            //Downloading
            var downloading = document.getElementById("whatToPrint");
            var doc = new jsPDF('l', 'pt');

            await html2canvas(downloading, {
                //allowTaint: true,
                //useCORS: true,
                width: 1000
            }).then((canvas) => {
                //Canvas (convert to PNG)
                doc.addImage(canvas.toDataURL("image/png"), 'PNG', 5, 5, 1000, 2000);
            })

            doc.save("Document.pdf");

            //End of downloading

            document.getElementById("downloadButton").innerHTML = "Click to download";
        }
    </script>
</body>
</html>

<!--

HTML + CSS -> PNG (html2canvas)
PNG -> Add to PDF (jsPDF)
Download PDF (jsPDF)

-->