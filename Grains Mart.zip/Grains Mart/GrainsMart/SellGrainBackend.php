<?php
include("connect.php");
session_start();
$grain_type = $_REQUEST['grain_type'];
$variety = $_REQUEST['variety'];
$g_price = $_REQUEST['g_price'];
$g_stock = $_REQUEST['g_stock'];
$username = $_SESSION['farmer'];
$farmer_id = "";
$selectQuery = "SELECT f_id FROM farmer WHERE f_username = '".$username."'";
    $result = $conn->query($selectQuery);
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $farmer_id = $row["f_id"];
            echo $farmer_id;
        }
    }
    
    $insertQuery = "INSERT INTO grains(grains_name, grains_variety, grains_price, grains_stock, f_id) VALUES ('$grain_type', '$variety', '$g_price', '$g_stock', '$farmer_id')";
    
    if ($conn->query($insertQuery) === true) {
        header("Location: account.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
          
       

 ?>