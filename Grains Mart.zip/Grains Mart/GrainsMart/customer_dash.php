
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Customer Dashboard</title>
<link rel="stylesheet" href="css/farmer_dash.css">
<link rel="stylesheet" href="css/nav.css">

</head>
<body>
<div class="nav">
    <ul>
      <li class="logo">GrainsMart</li>
      <li class="active"><a href="account.php">Account</a></li>
     
      <li><a href="Grains.php">Cart</a></li>
      <li><a  href="AboutUs.html">About Us</a></li>
      <li><a href="index.php">Home</a></li>
    </ul>
  </div>
<section class="dashboard" id="udash">
<!--  <form action="" method="POST">-->
  <div class="dash" id="a_dash">
  <h1 style="text-align: center;">Customer Dashboard</h1>
    <div class="row">
      <button class="ref" name="tbooking" ><a href="CustomerProfile.php">
      <div class="element">
        <p>Profile</p>
      </div></a></button>
      <button class="ref" name="c-details"><a href="MyOrders.php">
      <div class="element" >
        <p>My Orders</p>
      </div></a></button>
    </div>
    
    <div class="row" style="margin-top:3%;">
    <button class="ref" name="editprice"><a href="feedback.php">
      <div class="element" >
        <p>Feedback</p>
      </div></a></button>
      <button class="ref" name="logOut"><a href="complain.php">
      <div class="element" >
        <p >Complaint</p>
      </div></a>
      </button>
    </div>

    <div class="row" style="margin-top:3%;">
    <button class="ref" name="editprice">
      <div class="element" >
        <p>Delivery Status</p>
      </div></a></button>
      <button class="ref" name="logOut"><a href="logout.php">
      <div class="element" >
        <p >Logout</p>
      </div></a>
      </button>
    </div>
  </div><!--</form>-->
</section>

</body>
</html>