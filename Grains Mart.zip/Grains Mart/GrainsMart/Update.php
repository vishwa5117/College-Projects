<?php
 session_start();
include("connect.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Update Price And Stock</title>
<link rel="stylesheet" href="css/bookform.css">
<link rel="stylesheet" href="css/nav.css">
</head>
<body>
<div class="nav">
    <ul>
      <li class="logo">GrainsMart</li>
      <li class="active"><a href="account.php">Account</a></li>
      <li><a href="SellGrain.php">Sell Grains</a></li>
      <li><a href="Grains.php">Order Grains</a></li>
      <li><a href="AboutUs.html">About Us</a></li>
      <li><a href="index.php">Home</a></li>
    </ul>
</div>
<section class="mybookings" id="change-price">
  <div class="cp" id="cp">
    <button class="MyBkBtn" style="background:red; font-size:18px;"><a href="farmer_dash.php">Dashboard</a></button>
    <div class="cp1">
      <div style="border:1px solid black;background-color: #E4F5D4;margin-left:30px;padding:5px;">
        <form action="updateprice.php" method="POST">
          <h2 style="text-align:center;">Update Price & Stock</h2>
          <p><b>Change Grains Price:</b></p>
          <input type="number" name="g_id" placeholder="Enter Grain Id"  required min="1">
          <input type="number" name="g_price" placeholder="Enter New Selling Price"  required min="1">
          <input type="submit" name="hall_p_btn" value="Update">
        </form>
        <form action="updatestock.php" method="POST">
          <br>
          <p><b>Change Grains Stock</b></p>
          <input type="number" name="g_id" placeholder="Enter Grain Id"  required min="1">
          <input type="number" name="g_stock" placeholder="Enter New Stock" min="100" required min="1">
          <input type="submit" name="service_p_btn" value="Update">
        </form>
        <form action="removegrain.php" method="POST">
          <br>
          <p><b>Remove Grains</b></p>
          <input type="number" name="g_id" placeholder="Enter Grain Id" required min="1">
          <input type="submit" name="service_p_btn" value="Delete">
        </form>
      </div>
      <table>
        <tr>
          <th>Grain Id</th>
          <th>Grain Name</th>
          <th>Grain Variety</th>
          <th>Selling Price</th>
          <th>Total Stock</th>
        </tr>
        <?php
        $username = $_SESSION["farmer"];
        $f_id = "";
        try {
          
          $sql1 = "SELECT * FROM farmer WHERE f_username='" . $username . "'";
          $result1 = $conn->query($sql1);
          while ($row1 = $result1->fetch_assoc()) {
            $f_id = $row1["f_id"];
          }
          $sql = "SELECT * FROM grains WHERE f_id='" . $f_id . "'";
          $result = $conn->query($sql);
          while ($row = $result->fetch_assoc()) {
        ?>
          <tr>
            <td><?php echo $row["grains_id"]; ?></td>
            <td><?php echo $row["grains_name"]; ?></td>
            <td><?php echo $row["grains_variety"]; ?></td>
            <td><?php echo $row["grains_price"]; ?></td>
            <td><?php echo $row["grains_stock"]; ?></td>
          </tr>
        <?php
          }
        } catch (Exception $e) {
          echo $e;
        }
        ?>
      </table>
    </div>
  </div>
</section>
</body>
</html>
