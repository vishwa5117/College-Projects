<?php
 
include("connect.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="ISO-8859-1">
    <title>Farmer Profile</title>
    <link rel="stylesheet" href="css/FarmerProfile.css">
    <link rel="stylesheet" href="css/nav.css">
</head>
<body>
<div class="nav">
    <ul>
        <li class="logo">GrainsMart</li>
        <li class="active"><a href="account.php">Account</a></li>
        <li><a href="SellGrain.php">Sell Grains</a></li>
        <li><a href="Grains.php">Order Grains</a></li>
        <li><a href="AboutUs.html">About Us</a></li>
        <li><a href="index.php">Home</a></li>
    </ul>
</div>

<section class="profile" id="profile1">
    <?php
    session_start();
    $username = $_SESSION['customer'];

    try {
        
        $selectQuery = "SELECT * FROM customer WHERE c_username = '".$username."'";
        $result = $conn->query($selectQuery);

        while ($row = $result->fetch_assoc()) {
            $name = $row["c_Name"];
            $id = $row["c_id"];
            $email = $row["c_email"];
            $address = $row["c_Address"];
            $mobile = $row["c_MobileNo"];
            ?>

            <div class="userprofile">
                <h2>Profile</h2>
                <p class="point"><b>Id:</b><?php echo $row["c_id"]; ?></p>
                <p class="point"><b>User Name:</b><?php echo $row["c_username"]; ?></p>
                <p class="point"><b>Name:</b><?php echo $row["c_Name"]; ?></p>
                <p class="point"><b>Email:</b><?php echo $row["c_email"]; ?></p>
                <p class="point"><b>Mobile Number:</b><?php echo $row["c_MobileNo"]; ?></p>
                <p class="point"><b>Address:</b><?php echo $row["c_Address"]; ?></p>
                <button class="ProfileBtn"><a href="customer_dash.php">OK</a></button>
            </div>
        <?php
        }

        $conn->close();
    } catch (Exception $e) {
        echo $e;
    }
    ?>
</section>
</body>
</html>
