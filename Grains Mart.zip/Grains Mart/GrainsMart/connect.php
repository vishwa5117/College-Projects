<?php
                                                  
		// servername => localhost
		// username => root
		// password => empty
		// database name => book_event
     
      $conn = mysqli_connect("localhost", "root", "", "grainsmart");
		
		// Check connection
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
        
		}
?>