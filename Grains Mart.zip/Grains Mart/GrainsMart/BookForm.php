<?php
session_start(); 
include("connect.php");


//echo $_SESSION["customer"];
    if(isset($_SESSION['customer'])){
    	$str1=$_POST['1'];
	

    	$grain="";
    	if($str1!=null){
    		$grain=$str1;}
    	
    ?>
    	<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Account</title>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Now</title>
    <link rel="stylesheet" href="css/bookform.css">
        <link rel="stylesheet" href="css/nav.css">
    

</head>
<body>
<div class="nav">
    <ul>
      <li class="logo">GrainsMart</li>
      <li class="active"><a href="account.php">Account</a></li>
      <li><a href="SellGrain.php">Sell Grains</a></li>
      
      <li><a href="Grains.php">Order Grains</a></li>
      <li><a  href="AboutUs.html">About Us</a></li>
      <li><a href="index.php">Home</a></li>
    </ul>
  </div>
  
<section class="mybookings" id="mybooking" >
  <div class="mb" id="mb" >
<table>
	    <tr>
		<th> Grain Id</th>
		<th>Grain Name</th>
		<th>Grain Variety</th>
		<th>Selling Price</th>
        <th>Total Stock</th>
        <th>Farmer Id</th>
        </tr>
			<?php
			       
		          
					$query = "select * from grains where grains_name='$grain'";
					$result = mysqli_query($conn, $query);
					//echo $result;
					if ($result) {
						// Fetch the hall ID from the query result
						while ($row = mysqli_fetch_assoc($result)) {			   
		        	 

			?>
			<tr>
				<!--FETCHING DATA FROM EACH
					ROW OF EVERY COLUMN-->
				<td><?php echo $row['grains_id'];?></td>
				<td><?php echo $row['grains_name']?></td>
				<td><?php echo $row['grains_variety']?></td>
				<td><?php echo $row['grains_price']?></td>
                <td><?php echo $row['grains_stock']?></td>
                <td><?php echo $row['f_id']?></td>
                <td><form action="book.php" method="post">
                <input type="text" name="id" value="<?php echo $row['grains_id']?>" style="display:none">
                <input type="submit" value="Order Now"></form></td>
			</tr>
      
			<?php
				
					}
				}
			}
        
			?>
      <button class="MyBkBtn" style="background:red; font-size:18px;"><a href="Grains.php">Close Table</button>
		</table></div>
</section>
</body>
 
</html>
		   
	 