
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Farmer Dashboard</title>
<link rel="stylesheet" href="css/farmer_dash.css">
<link rel="stylesheet" href="css/nav.css">

</head>
<body>
<div class="nav">
    <ul>
      <li class="logo">GrainsMart</li>
      <li class="active"><a href="logout.php">Log-Out</a></li>
      <li class="active"><a href="account.php">Account</a></li>
  
    
      <li><a  href="AboutUs.html">About Us</a></li>
      <li><a href="index.php">Home</a></li>
    </ul>
  </div>
<section class="dashboard" id="udash">
<!--  <form action="" method="POST">-->
  <div class="dash" id="a_dash">
  <h1 style="text-align: center;">Farmer Dashboard</h1>
    <div class="row">
      <button class="ref" name="tbooking" ><a href="FarmerProfile.php">
      <div class="element">
        <p>Profile</p>
      </div></a></button>

      <button class="ref" name="c-details"><a href="orders.php">
      <div class="element" >
        <p>Orders</p>
      </div></a></button>
    </div>

    <div class="row" style="margin-top:3%;">
    <button class="ref" name="editprice"><a href="CustomerDetail.php">
      <div class="element" >
        <p>Customer Details</p>
      </div></a></button>

      <button class="ref" name="logOut"><a href="Update.php">
      <div class="element" >
        <p>Manage Grains</p>
      </div></a>
      </button>
    </div>

    <div class="row" style="margin-top:6%;"> <a href="f_feedback.php">
    <button class="ref" name="editprice">
      <div class="element" >
        <p>View feedback</p>
      </div></a></button>

      

      <button class="ref" name="logOut"><a href="f_complaint.php">
      <div class="element" >
        <p >View Complaint</p>
      </div></a>
      </button>
    </div>
    
  </div><!--</form>-->
</section>

</body>
</html>