<?php
include("connect.php");

session_start();
$username = $_SESSION["farmer"];
$f_id = "";
$g_id = $_POST["g_id"];
$g_stock = $_POST["g_stock"];

try {
    
    $sql1 = "SELECT * FROM farmer WHERE f_username='" . $username . "'";
    $result1 = $conn->query($sql1);
    while ($row1 = $result1->fetch_assoc()) {
        $f_id = $row1["f_id"];
    }
    $sql = "SELECT * FROM grains WHERE f_id='" . $f_id . "'";
    $result = $conn->query($sql);
    $grainFound = false;
    while ($row = $result->fetch_assoc()) {
        if ($g_id == $row["grains_id"]) {
            $grainFound = true;
            $sqlUpdate = "UPDATE grains SET grains_stock='" . $g_stock . "' WHERE grains_id='" . $g_id . "'";
            if ($conn->query($sqlUpdate) === TRUE) {
                header("Location: Update.php");
                exit();
            } else {
                echo "Error updating grain stock: " . $conn->error;
            }
            break;
        }
    }
    if (!$grainFound) {
?>
        <script>
            alert("Invalid Grain Id");
            location.replace("Update.php");
        </script>
<?php
    }
} catch (Exception $e) {
    echo $e;
}
?>
