<?php
session_start(); 
include("connect.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Order Grains</title>
<link rel="stylesheet" href="css/book.css">
<link rel="stylesheet" href="css/nav.css">

</head>
<body>
<div class="nav">
    <ul>
      <li class="logo">GrainsMart</li>
      <li class="active"><a href="account.php">Account</a></li>
      <li><a href="SellGrain.php">Sell Grains</a></li>
      
      <li><a href="Grains.php">Order Grains</a></li>
      <li><a  href="AboutUs.html">About Us</a></li>
      <li><a href="index.php">Home</a></li>
    </ul>
  </div>
<section class="profile" id="profile1">
<?php

    	 $grain_id=$_POST['id'];

	    	$query = "select * from grains where grains_id='$grain_id'";
					$result = mysqli_query($conn, $query);
					//echo $result;
					if ($result) {
						// Fetch the hall ID from the query result
						while ($row = mysqli_fetch_assoc($result)) {	
	    	
	    ?>
	    


<div class="userprofile">
  <h2>Order Grains</h2>
  <p class="point"><b>Grain Id:</b><?php echo $row['grains_id'];?> </p>
      <p class="point"><b>Grain Name:</b><?php echo $row['grains_name'];?> </p>
      <p class="point"><b>Grain Variety:</b><?php echo $row['grains_variety'];?></p>
      <p class="point"><b>Grain Price:</b><?php echo $row['grains_price'];?></p>
   <form action="bill.php" method="post">
   <div class="form-element">
       <label for="quantity">Order Quantity</label>
       <input type="number" id="quantity" name="quantity" required placeholder="Enter Quantity" min="20">
<input type="text" name="id" value="<?php echo $row['grains_id'];}}?>" style="display:none">
     </div>
     <div class="form-element">
       <label for="address">Delivery Address</label>
       <input type="text" id="address"name="address"  required placeholder="Enter Address">
     </div>
      <div class="form-element">
      
       <input type="submit" id="submit"name="submit" value="Submit">
     </div>
   </form>   
      
</div>
</section>
</body>
</html>