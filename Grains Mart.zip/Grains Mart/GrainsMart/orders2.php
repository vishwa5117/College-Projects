<?php
include("connect.php");
session_start();

?>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Account</title>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Order Now</title>
<link rel="stylesheet" href="css/bookform.css">
<link rel="stylesheet" href="css/nav.css">
<link rel="stylesheet" href="css/form.css">
</head>
<body>
<div class="nav">
    <ul>
        <li class="logo">GrainsMart</li>
        <li class="active"><a href="account.php">Account</a></li>
        <li><a href="SellGrain.php">Sell Grains</a></li>
        <li><a href="Grains.php">Order Grains</a></li>
        <li><a href="AboutUs.html">About Us</a></li>
        <li><a href="index.php">Home</a></li>
    </ul>
</div>

<section class="mybookings" id="mybooking">
  <div class="mb" id="mb">
    <table>
      <tr>
        <th>Order Id</th>
        <th>Grains Id</th>
        <th>Grains Name</th>
        <th>Grains Variety</th>
        <th>Grains Price</th>
        <th>Ordered Quantity</th>
        <th>Total Bill</th>
        <th>Delivery Address</th>
        <th>Order date</th>
        <th>Customer Id</th>
        <th>Customer Name</th>
        <th>Email</th>
        <th>Contact Number</th>
      </tr>
      <?php
      $username = $_SESSION["farmer"];
      $m_year = $_POST["m_year"];
      $f_id = "";
      try {
          
          $sql1 = "SELECT * FROM farmer WHERE f_username='" . $username . "'";
          $result1 = $conn->query($sql1);
          while ($row1 = $result1->fetch_assoc()) {
              $f_id = $row1["f_id"];
          }
          if (!empty($m_year)) {
              $sql2 = "SELECT * FROM order1 WHERE f_d='" . $f_id . "' AND YEAR(order_date)='" . $m_year . "'";
              $result2 = $conn->query($sql2);
              while ($row2 = $result2->fetch_assoc()) {
                  $c_id = $row2["c_id"];
      ?>
      <tr>
        <td><?php echo $row2["order_id"]; ?></td>
        <td><?php echo $row2["g_id"]; ?></td>
        <td><?php echo $row2["grains_name"]; ?></td>
        <td><?php echo $row2["grains_variety"]; ?></td>
        <td><?php echo $row2["grains_price"]; ?></td>
        <td><?php echo $row2["order_quantity"]; ?></td>
        <td><?php echo $row2["total_bill"]; ?></td>
        <td><?php echo $row2["delivery_add"]; ?></td>
        <td><?php echo $row2["order_date"]; ?></td>
        <td><?php echo $c_id; ?></td>
        <td><?php echo $row2["c_Name"]; ?></td>
        <td><?php echo $row2["c_email"]; ?></td>
        <td><?php echo $row2["c_MobileNo"]; ?></td>
      </tr>
      <?php
              }
          }
          $conn->close();
      } catch (Exception $e) {
          echo $e;
      }
      ?>
      <button class="MyBkBtn" style="background:red; font-size:18px;"><a href="orders.php">Close Table</a></button>
    </table>
  </div>
</section>
</body>
</html>
