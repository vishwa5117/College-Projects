<?php

 
include("connect.php");

session_start();
$username = $_SESSION['farmer'];
$f_id = '';
$g_id = $_POST['g_id'];

try {
   

    $selectQuery = "SELECT * FROM farmer WHERE f_username = '".$username."'";
    $result = $conn->query($selectQuery);
    $row1 = $result->fetch_assoc();
    $f_id = $row1['f_id'];

    $selectGrainQuery = "SELECT * FROM grains WHERE f_id = '".$f_id."'";
    $grainResult = $conn->query($selectGrainQuery);
    
    $grainFound = false;
    while ($row = $grainResult->fetch_assoc()) {
        if ($g_id == $row['grains_id']) {
            $grainFound = true;
            $deleteQuery = "DELETE FROM grains WHERE grains_id = '".$g_id."'";
            if ($conn->query($deleteQuery) === true) {
                header("Location: Update.php");
                exit;
            } else {
                echo "Error deleting grain: " . $conn->error;
            }
            break;
        }
    }

    if (!$grainFound) {
        echo "<script>alert('Invalid Grain ID');
              location.replace('Update.php');
              </script>";
    }

    $conn->close();
} catch (Exception $e) {
    echo $e;
}
?>
