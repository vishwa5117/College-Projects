<?php
 
include("connect.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account</title>
    <link rel="stylesheet" href="css/bookform.css">
    <link rel="stylesheet" href="css/nav.css">
</head>
<body>
<div class="nav">
    <ul>
        <li class="logo">GrainsMart</li>
        <li class="active"><a href="account.php">Account</a></li>
        <li><a href="SellGrain.php">Sell Grains</a></li>
        <li><a href="AboutUs.html">About Us</a></li>
        <li><a href="index.php">Home</a></li>
    </ul>
</div>

<section class="mybookings" id="mybooking">
    <h2 style="text-align:center;">Feedback Detail</h2>
    <div class="mb" id="mb">
        <table>
            <tr>
                <th>feed_id</th>
                <th>cust_id</th>
                <th>Name</th>
                <th>Email</th>
                <th>MobileNo</th>
                <th>Address</th>
                <th>Feedback</th>
                
            </tr>
            <?php
            session_start();
            $username = $_SESSION['farmer'];
            $f_id = "";
            $c_id = "";

            
                

                $selectFarmerQuery = "SELECT * FROM feedback";
                $result1 = $conn->query($selectFarmerQuery);
                if ($result1->num_rows > 0) {
                    while ($row1 = $result1->fetch_assoc()) {
                        $c_id = $row1["c_id"];
                   $desc=$row1["decscription"];
                   $feed=$row1["feed_id"];

                $selectOrderQuery = "SELECT * FROM customer WHERE c_id = '".$c_id."'";
                $result = $conn->query($selectOrderQuery);
                while ($row = $result->fetch_assoc()) {
                    $c_id = $row["c_id"];
                    $selectCustomerQuery = "SELECT * FROM customer WHERE c_id = '".$c_id."'";
                    $result2 = $conn->query($selectCustomerQuery);
                    while ($row2 = $result2->fetch_assoc()) {
                        ?>
                        <tr>
                            <td><?php echo $feed; ?></td>
                            <td><?php echo $c_id; ?></td>
                            <td><?php echo $row2["c_Name"]; ?></td>
                            <td><?php echo $row2["c_email"]; ?></td>
                            <td><?php echo $row2["c_MobileNo"]; ?></td>
                            <td><?php echo $row2["c_Address"]; ?></td>
                            <td><?php echo $desc; ?></td>
                        </tr>
                        <?php
                    }
                }

               
            } }
            ?>
        </table>
    </div>
</section>
