
    
    <?php
     include("connect.php");
	 session_start();
    if($_SESSION['customer']){
		header("Location: customer_dash.php", true, 301);  
    exit();
    	
		   
	   }
    else if($_SESSION['farmer']){
				header("Location: farmer_dash.php", true, 301);  
    exit();
	   }
    else{
      header("Location: login.html", true, 301);  
      exit();    	}
   
    ?>
