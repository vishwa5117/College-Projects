
 
<?php
include("connect.php");
session_start();
$login_type=$_POST['login_type'];
//echo $login_type;
$username=$_POST['user_name'];
$pass=$_POST['user_password'];
$flag=0;
 

           if(isset($_POST['user_login'])){
			if($login_type==1){
				
			   $sql = "SELECT * FROM customer WHERE c_username='$username' && c_password='$pass'";  
			   $query = mysqli_query($conn, $sql);
				  
				
				$count = mysqli_num_rows($query);  
				
				if($count==1){ 
			  
				  $_SESSION["customer"]=$username;
				  header("Location: customer_dash.php", true, 301);  
				  exit();
				}else{?>
				<script>alert("Invalid Email and Password");
				window.location.href ="login.html";
				</script><?php
			  
				}}
            else if($login_type==2){
			
			  
			   $sql = "SELECT * FROM farmer WHERE f_username='$username' AND f_password='$pass'";  
			   $query = mysqli_query($conn, $sql);
				  
				
				$count = mysqli_num_rows($query);  
				
				if($count==1){ 
			  
				  $_SESSION["farmer"]=$username;
				  header("Location: farmer_dash.php", true, 301);  
				  exit();
				}else{?>
				<script>alert("Invalid Email and Password");
				window.location.href ="login.html";
				</script><?php
			  
				}
			}}?>