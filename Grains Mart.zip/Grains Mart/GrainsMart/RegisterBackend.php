<?php
include("connect.php");
session_start();

$login_type=$_POST['login_type'];
$username=$_POST['user_name'];
$name=$_POST['u_name'];
$mobile_no=$_POST['u_mob'];
$email=$_POST['u_email'];
$add=$_POST['add'];
$pass=$_POST['u_password'];
$c_pass=$_POST['uc_password'];

//compair pass and confirm pass to proceed
if($pass==$c_pass){

           //if 1(customer) login then insert customer data in customer table
           if($login_type==1){
            $sql="insert into customer(c_username,c_password,c_Name,c_email,c_MobileNo,c_Address)values('$username','$pass','$name','$email','$mobile_no','$add')";
            $query = mysqli_query($conn, $sql);
            if($query){
              echo'<script> alert("Customer Registration successful");
              window.location.href ="login.html";</script>';
            }
             
             }
           else if($login_type==2){
            $sql="insert into farmer(f_username,f_password,f_Name,f_email,f_MobileNo,f_Address)values('$username','$pass','$name','$email','$mobile_no','$add')";
            $query = mysqli_query($conn, $sql);
            if($query){
              echo'<script> alert("Farmer Registration successful");
              window.location.href ="login.html";</script>';
            }else{
              echo'<script>alert("Invalid error");</script>';
            }
             
             }
      else{
        echo'<script>alert("Invalid Entries");</script>';
	
}}
 ?>