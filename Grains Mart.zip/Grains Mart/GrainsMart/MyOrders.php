<?php
 
include("connect.php");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="ISO-8859-1">
    <title>Account</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Order</title>
    <link rel="stylesheet" href="css/bookform.css">
    <link rel="stylesheet" href="css/nav.css">
</head>
<body>
<div class="nav">
    <ul>
        <li class="logo">GrainsMart</li>
        
        <li class="active"><a href="account.php">Account</a></li>
        <li><a href="Grains.php">Cart</a></li>
        <li><a href="AboutUs.html">About Us</a></li>
        <li><a href="index.php">Home</a></li>
    </ul>
</div>

<section class="mybookings" id="mybooking">
    <div class="mb" id="mb">
        <table>
            <tr>
                <th>Order Id</th>
                <th>Grains Id</th>
                <th>Grains Name</th>
                <th>Grains Variety</th>
                <th>Grains Price</th>
                <th>Ordered Quantity</th>
                <th>Total Bill</th>
                <th>Delivery Address</th>
                <th>Farmer Id</th>
                <th>Farmer Name</th>
                <th>Farmer Email</th>
                <th>Contact Number</th>
            </tr>
            <?php
            session_start();
            $username = $_SESSION['customer'];

            try {
                

                $selectQuery = "SELECT * FROM customer WHERE c_username = '".$username."'";
                $result = $conn->query($selectQuery);
                $row1 = $result->fetch_assoc();
                $c_id = $row1["c_id"];

                $selectOrderQuery = "SELECT * FROM order1 WHERE c_id = '".$c_id."'";
                $orderResult = $conn->query($selectOrderQuery);

                while ($row = $orderResult->fetch_assoc()) {
                    $f_id = $row["f_d"];
                    $g_id = $row["g_id"];
                    ?>
                    <tr>
                        <td><?php echo $row["order_id"]; ?></td>
                        <td><?php echo $row["g_id"]; ?></td>
                        <td><?php echo $row["grains_name"]; ?></td>
                        <td><?php echo $row["grains_variety"]; ?></td>
                        <td><?php echo $row["grains_price"]; ?></td>
                        <td><?php echo $row["order_quantity"]; ?></td>
                        <td><?php echo $row["total_bill"]; ?></td>
                        <td><?php echo $row["delivery_add"]; ?></td>
                        <td><?php echo $f_id; ?></td>
                        <td><?php echo $row["f_Name"]; ?></td>
                        <td><?php echo $row["f_email"]; ?></td>
                        <td><?php echo $row["f_MobileNo"]; ?></td>
                    </tr>
                    <?php
                }

                $conn->close();
            } catch (Exception $e) {
                echo $e;
            }
            ?>
        </table>
        <button class="MyBkBtn" style="background:red; font-size:18px;"><a href="customer_dash.php">Close Table</button>
    </div>
</section>
</body>
</html>
